/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree_main;

/**
 *
 * @author sandi
 */
public class Tree_main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        tree root  = new tree(40);
        root.left = new tree(30);
        root.right = new tree(50);
        root.left.left = new tree(25);
        root.left.right = new tree(35);
        root.right.left = new tree(45);
       root.right.right = new tree(55);
       /* System.out.println("PreOrder Output");
        root.preOrder(root);
        System.out.println("InorderOutput");
        root.inOrder(root);
        System.out.println("postOrder");
        root.postOrder(root);
        System.out.println("height of tree "+ root.height(root));
       // System.out.println("width of 2nd level"+ root.width(root,2));
       System.out.println("binary or not" +" " + root.binary(root));*/
      // System.out.println(" max of tree"+ root.max(root));
      
    //
   //root.levelOrder(root);
  // root.printPaths(root);
  tree node1 = root.left;
  tree node2 = root.right;
   // System.out.println(root.isSibling(root, node1, node2));
   root.inOrder(root);
   //System.out.println(root.iseven(root))
   root.mirror(root);
   System.out.println( "  ");
   root.inOrder(root);
 //  System.out.println(h);
        
    }
    
}
