/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree_main;

/**
 *
 * @author sandi
 */
class tree {  int data;
    tree left;
    tree right;
    
    tree(int data){
        this.data = data;
        
    }
    tree()
    {
        
    }
  
    void preOrder( tree root)
    {
        if(root == null)
            return;
        else
            System.out.print(root.data + " ");
            
            preOrder(root.left);
            preOrder(root.right);
    }
     void inOrder( tree root)
    {
        if(root == null)
            return;
        else
            
            inOrder(root.left);
        System.out.print(root.data + " ");
            inOrder(root.right);
    }
     void postOrder( tree root)
    {
        if(root == null)
            return;
        else
            
            postOrder(root.left);
       
        
            postOrder(root.right);
             System.out.print(root.data + " ");
    }
     int height(tree root)
     {
         if(root == null)
         return 0;
         else {
                 int rdepth = height(root.right);
                 int ldepth = height(root.left);
                 if(rdepth > ldepth)
                 { return rdepth+1;
                 
                 }
                 else
                     return ldepth+1;
                 }
     }
     int width(tree root , int level)
     {
         if(root == null)
         {
             return 0;
         }
         if(level == 1) 
             return 1;
         else if (level > 1)
         {
             return  (width(tree.left, level-1) + width(tree.right, level-1));
         }
         return 0;
     }
     boolean binary(tree root)
     {
         if(root == null)
         {
             return false;
             
         }
         if(root.left == null && root. right == null)
         {
             return true;
         }
         if((root.left!=null && root.right!=null))
         {return true;
         }
       
        if(binary(root.left) && binary(root.right))
        {
         return true;
         
        } 
                // return 1;
     
    return false;
     }
     
     int max(tree root)
     {
         while(root.left!= null)
         {
             root = root.left;
         }
         return root.data;
     }
     void levelOrder(tree root)
     {
         int h = root.height(root);
         for(int i =0 ; i  < h+1 ;i++)
         { getlevel(root,i);
         
         }
     }
     void getlevel( tree root,int level)
     {
         if(level == 0)
         { return;
         }
         if(level ==1){
             System.out.print(root.data + " ");
         
         }
         else 
             getlevel(root.left, level-1);
             getlevel(root.right, level-1);
         
         
     } void printPaths(tree node)
     {
        int path[] = new int[1000];
        printPathsRecur(node, path, 0);
    }
  
    /* Recursive helper function -- given a node, and an array containing
       the path from the root node up to but not including this node,
       print out all the root-leaf paths. */
    void printPathsRecur(tree node, int path[], int pathLen) 
    {
        if (node == null)
            return;
  
        /* append this node to the path array */
        path[pathLen] = node.data;
        pathLen++;
  
        /* it's a leaf, so print the path that led to here */
        if (node.left == null && node.right == null)
            printArray(path, pathLen);
        else
            { 
            /* otherwise try both subtrees */
            printPathsRecur(node.left, path, pathLen);
            printPathsRecur(node.right, path, pathLen);
        }
    }
  
    /* Utility that prints out an array on a line */
    void printArray(int ints[], int len) 
    {
        int i;
        for (i = 0; i < len; i++) 
            System.out.print(ints[i] + " ");
        System.out.println("");
    }
    
    void levelprint(tree root, int data, int lev)
    {
        
        if(root== null)
            return;
        if(root.data==data)
            System.out.println(lev);
        else{
            
            levelprint(root.left ,data,lev+ 1);
            levelprint(root.right,data, lev+1);
        }
        
        
  
        
    }
    boolean isSibling(tree node, tree a, tree b)
    {
        // Base case
        if (node == null)
            return false;
 
        return ((node.left == a && node.right == b) ||
                (node.left == b && node.right == a) ||
                isSibling(node.left, a, b) ||
                isSibling(node.right, a, b));
    }
    
    int size(tree root)
    { if(root == null)
        return 0;
        if(root.left!= null && root.right != null)
                {
            return (1+ size(root.left)+ size(root.right));
        
        
    } else
            
        return (size(root.left)+ size(root.right));
}
    
    boolean iseven(tree root)
    {
        if(root!= null)
        {if(iseven(root.left)==iseven(root.right))
            return false;
            
        }
        else 
        {
            return true;
        }
        return true;
    }
    
    void mirror(tree root)
    { tree temp;
    
        if(root == null)
            return;
        else
        {  mirror(root.left);
            mirror(root.right);
            
            temp = root.left;
            root.left = root.right;
            root.right = temp;
        }
           
    }
}


